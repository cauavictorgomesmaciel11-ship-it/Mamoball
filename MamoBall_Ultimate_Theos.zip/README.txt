COMO COMPILAR

1. Instale o Theos no macOS
2. Coloque esta pasta em:
   ~/theos/projects/

3. Abra o terminal na pasta
4. Execute:

make package

ou:

make

A dylib compilada ficará em:
.obj/debug/

ou o .deb em:
packages/

Depois:
- injete a dylib no IPA usando ESign/Scarlet/Sideloadly
- assine o IPA
- instale no iPhone
